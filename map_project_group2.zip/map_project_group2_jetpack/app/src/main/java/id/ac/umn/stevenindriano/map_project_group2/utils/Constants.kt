package id.ac.umn.stevenindriano.map_project_group2.utils

class Constants {
    companion object {
        //route
        const val HOME_ROUTE = "home_route"
        const val SETTING_ROUTE = "setting_route"
    }
}