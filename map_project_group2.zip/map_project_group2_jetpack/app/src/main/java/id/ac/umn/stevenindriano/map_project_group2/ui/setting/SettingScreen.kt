package id.ac.umn.stevenindriano.map_project_group2.ui.setting

import androidx.compose.runtime.Composable

@Composable
fun SettingScreen() {
    
}
